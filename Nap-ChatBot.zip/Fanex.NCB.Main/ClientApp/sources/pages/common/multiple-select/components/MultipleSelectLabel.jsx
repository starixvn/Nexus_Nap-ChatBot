import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Translation from './translation';
import { MAX_SELECTED_ITEM_FOR_DISPLAY } from '../constants';

export default class MultipleSelectLabel extends Component {
    static propTypes = {
        language: PropTypes.string,
        selectedItems: PropTypes.arrayOf(PropTypes.object).isRequired,
        maxDisplayItemCount: PropTypes.number
    };

    static defaultProps = {
        language: 'en-US',
        maxDisplayItemCount: MAX_SELECTED_ITEM_FOR_DISPLAY,
        texts: {
            All: 'All',
            SelectedItemCount: '# selected',
            SelectOptions: 'Select options',
            None: 'None'
        }
    };

    get selectedItemsString() {
        const { selectedItems, maxDisplayItemCount } = this.props;
        const selectedValues = selectedItems.map(item => item.value);
        const texts = this.props.texts || Translation[this.props.language];

        let displayText = texts.SelectOptions;
        const selectedItemCount = selectedValues.length;

        if(this.props.isAllTextShown && selectedItemCount === this.props.dataSourceSize){
            displayText = texts.All;
        } else if (selectedItemCount > maxDisplayItemCount) {
            displayText = texts.SelectedItemCount.replace('#', selectedItemCount);
        } else if (selectedItemCount >= 1) {
            displayText = selectedValues.join(', ');
        } else if (selectedItemCount === 0 && this.props.hasNoneOption) {
            displayText = texts.None;
        }

        return displayText;
    }

    render() {
        return (
            <button type="button" className="multiple-select-default multiple-select-label"
                onClick={this.props.onToggle}>
                <span className="text-display">{this.selectedItemsString}</span>
                <b className="caret"></b>
            </button>
        );
    }
}