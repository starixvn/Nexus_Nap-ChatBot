﻿namespace Fanex.NCB.Core.Constants
{
    public static class Language
    {
        public const string en_US = "en-US";
        public const string zh_CN = "zh-CN";
        public const string vi_VN = "vi-VN";
        public const string th_TH = "th-TH";
    }
}
