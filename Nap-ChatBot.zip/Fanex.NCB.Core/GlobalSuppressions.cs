﻿// This file is used by Code Analysis to maintain SuppressMessage
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Major Code Smell", "S3996:URI properties should not be strings",
    Justification = "<Pending>", Scope = "member", Target = "~P:Fanex.NCB.Core.Models.BotSettings.TokenUrl")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Major Code Smell", "S3996:URI properties should not be strings",
    Justification = "<Pending>", Scope = "member", Target = "~P:Fanex.NCB.Core.Models.BotSettings.AuthenticateUrl")]